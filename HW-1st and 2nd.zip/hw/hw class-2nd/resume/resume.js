// ! onclick
function resumepic() {
  var photodata = document.getElementById("resume-photo").innerHTML;
  document.getElementById("photocontain").innerHTML = photodata;
}

function resume() {
  // ! getting of data

  var namedata = document.getElementById("name").value;
  var surnamedata = document.getElementById("surname").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var city = document.getElementById("city").value;
  var country = document.getElementById("country").value;

  // ! Printing of Data

  document.getElementById("namecontain").innerHTML = namedata;
  document.getElementById("surnamecontain").innerHTML = surnamedata;
  document.getElementById("emailcontain").innerHTML = email;
  document.getElementById("phonecontain").innerHTML = phone;
  document.getElementById("citycontain").innerHTML = city;
  document.getElementById("countrycontain").innerHTML = country;
}
